// Scroll to specific section
function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
}

// Show QR Code
function showQR() {
    document.getElementById("qrCode").classList.toggle("hidden");
}

// Back to Top Button Functionality
window.onscroll = function() {
    let backToTopBtn = document.getElementById("backToTop");
    if (document.documentElement.scrollTop > 300) {
        backToTopBtn.style.display = "block";
    } else {
        backToTopBtn.style.display = "none";
    }
};
function toggleMenu() {
    const menu = document.getElementById("nav-links");
    menu.classList.toggle("active");
}



function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
